package com.example.Sorting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SortingVisualizerApplicationTests {

	@Test
	void contextLoads() {
	}

}
